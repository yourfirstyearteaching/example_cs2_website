#pragma once

/* You may modify the private section
 * of this file, but NOT the public section
 */

#include "vector.h"

using namespace std;

const int NUMSIDES = 4;

enum Connection {
    ABOVE,
    RIGHT,
    BELOW,
    LEFT,
};

class Tile {
public:
    Tile();
    Tile(string s);

    bool isMatched(Tile &other, Connection otherLocation);
    int getOrientation();
    void setOrientation(int orientation);
    string sidesStr() const;
    friend ostream &operator<<(ostream &out, Tile const &tile);

private:
    int orientation;
    Vector<string> sides;
};
