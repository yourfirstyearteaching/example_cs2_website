#include "PlayGame.h"
#include <cctype>
#include "vector.h"
#include "strlib.h"

/* DO NOT MODIFY THIS FILE UNLESS YOU
 * ARE WORKING ON AN EXTENSION
 */

using namespace std;

PlayGame::PlayGame(TileGrid &tg, bool (*allMatch)(Grid<Tile> &)) {
    mouseDown = false;
    currIm = nullptr;
    this->allMatch = allMatch;
    playGameManually(tg);
}

void PlayGame::playGameManually(TileGrid &tg) {
    while (true) {
        GEvent e = waitForEvent(MOUSE_EVENT | KEY_EVENT);
        if (e.getEventClass() == MOUSE_EVENT) {
            if (!handleMouseEvent(tg, GMouseEvent(e))) {
                break;
            }
        } else if (e.getEventClass() == KEY_EVENT) {
            break;
        }
    }
}

bool PlayGame::handleMouseEvent(TileGrid &tg, GMouseEvent e) {
    EventType etype = e.getEventType();
    if (etype == MOUSE_PRESSED) {
        mousePressed(e);
    } else if (etype == MOUSE_DRAGGED) {
        mouseDragged(e, tg);
    } else if (etype == MOUSE_RELEASED) {
        mouseReleased(e, tg);
        // check to see if game is solved
        Grid<Tile> &tiles = tg.getGrid();
        if (allMatch(tiles)) {
            if (GOptionPane::showConfirmDialog("You solved the game!\n"
                   "Would you like to keep playing?") == GOptionPane::YES) {
                return true;
            } else {
                return false;
            }
        }
    }
    return true;
}

void PlayGame::mousePressed(GMouseEvent e) {
    //cout << "mouse pressed" << endl;
    origX = e.getX();
    origY = e.getY();
    mouseDown = true;
}

void PlayGame::mouseReleased(GMouseEvent e, TileGrid &tg) {
    //cout << "mouse released" << endl;
    mouseDown = false;
    if (currIm) {
        // we must have been dragging
        finishDrag(tg);
    } else {
        // the user clicked
        rotateImage(e, tg);
    }
}


void PlayGame::mouseDragged(GMouseEvent e, TileGrid &tg) {
    //cout << "mouse dragged" << endl;
    GImage *im;
    if (currIm) {
        im = currIm;
    } else {
        // find image that was clicked
        Map<string,ImageAndRotation> images = tg.getImages();
        for (string s : images) {
            GImage *possibleIm = images[s].im;
            if (fixedContains(possibleIm,images[s].orientation,{e.getX(),e.getY()})) {
                //cout << "Found image!" << endl;
                im = currIm = possibleIm;
                currImOrientation = images[s].orientation;
                origImCenterLoc = fixedGetCenterLocation(im,currImOrientation);
                break;
            }
        }
    }
    if (currIm) {
        im->move(e.getX()-origX,e.getY()-origY);
        im->sendToFront();
        origX = e.getX();
        origY = e.getY();
    }

}

void PlayGame::finishDrag(TileGrid &tg) {
        GImage *closestImg = nullptr;
        int closestOrientation;
        double closestDist;
        Map<string,ImageAndRotation> &images = tg.getImages();
        for (string s : images) {
            double distToImage;
            GImage *possibleIm = images[s].im;
            if (possibleIm == currIm) {
                distToImage = dist(fixedGetCenterLocation(currIm,currImOrientation),origImCenterLoc);
            } else {
                distToImage = dist(fixedGetCenterLocation(currIm,currImOrientation),
                                   fixedGetCenterLocation(possibleIm,images[s].orientation));
            }
            if (closestImg) {
                if (closestDist > distToImage) {
                    closestDist = distToImage;
                    closestImg = possibleIm;
                    closestOrientation = images[s].orientation;
                }
            } else {
                closestDist = distToImage;
                closestImg = possibleIm;
                closestOrientation = images[s].orientation;
            }

        }
        if (currIm == closestImg) {
            //currIm->setCenterLocation(origImCenterLoc);
            fixedSetCenterLocation(currIm,currImOrientation,origImCenterLoc);
        } else {
            fixedSetCenterLocation(currIm,currImOrientation,
                                   fixedGetCenterLocation(closestImg,closestOrientation));
            fixedSetCenterLocation(closestImg,closestOrientation,origImCenterLoc);
            // swap images in TileGrid and the Grid<Tile> &
            for (string sCurr : images) {
                if (images[sCurr].im == currIm) {
                    for (string sClosest : images) {
                        if (images[sClosest].im == closestImg) {
                            tg.swapImages(images[sClosest],images[sCurr]);
                        }
                    }
                }
            }
        }
        currIm = nullptr;

}

void PlayGame::rotateImage(GMouseEvent e, TileGrid &tg) {
    // the user clicked
    // rotate 90 degrees clockwise
    // find image that was clicked
    Map<string,ImageAndRotation> &images = tg.getImages();
    for (string s : images) {
        GImage *im = images[s].im;
        if (fixedContains(im, images[s].orientation,{e.getX(),e.getY()})) {
            origImCenterLoc = fixedGetCenterLocation(im,images[s].orientation);
            im->sendToFront();

            // rotate to original position (this is beacuse there is a bug in the
            im->rotate(90 * -images[s].orientation);

            // reset position to original center
            im->setCenterLocation(origImCenterLoc);

            // now rotate 90 degrees clockwise from original
            im->rotate(90 * (images[s].orientation - 1));
            if (images[s].orientation == 0) {
                images[s].orientation = NUMSIDES - 1;
            } else {
                images[s].orientation = (images[s].orientation - 1) % NUMSIDES;
            }
            tg.updateTile(images[s]);
            fixedSetCenterLocation(im,images[s].orientation,origImCenterLoc);
            break;
        }
    }
}

GPoint PlayGame::getCenter(GRectangle rect) {
    return {(rect.getX() + rect.getX() + rect.getWidth()) / 2,
                (rect.getY() + rect.getY() + rect.getHeight() / 2)};
}

double PlayGame::dist(GPoint a, GPoint b) {
    return sqrt((a.getX()-b.getX())*((a.getX()-b.getX()))+
                (a.getY()-b.getY())*((a.getY()-b.getY())));
}

bool PlayGame::fixedContains(GImage *im, int orientation, GPoint loc) {
    // for some reason, the contains method in GImage doesn't work for rotated images.
    switch(orientation) {
    case 1:
        loc = {loc.getX(),loc.getY()+TILE_PIXEL_DIM};
        break;
    case 2:
        loc = {loc.getX()+TILE_PIXEL_DIM,loc.getY()+TILE_PIXEL_DIM};
        break;
    case 3:
        loc = {loc.getX()+TILE_PIXEL_DIM,loc.getY()};
        break;
    }
    return im->contains(loc);
}

GPoint PlayGame::fixedGetCenterLocation(GImage *im, int orientation) {
    GPoint loc = im->getCenterLocation();

    switch(orientation) {
    case 1:
        loc = {loc.getX(),loc.getY()-TILE_PIXEL_DIM};
        break;
    case 2:
        loc = {loc.getX()-TILE_PIXEL_DIM,loc.getY()-TILE_PIXEL_DIM};
        break;
    case 3:
        loc = {loc.getX()-TILE_PIXEL_DIM,loc.getY()};
        break;
    }
    return loc;
}

void PlayGame::fixedSetCenterLocation(GImage *im, int orientation, GPoint loc) {
    switch(orientation) {
    case 1:
        loc = {loc.getX(),loc.getY()+TILE_PIXEL_DIM};
        break;
    case 2:
        loc = {loc.getX()+TILE_PIXEL_DIM,loc.getY()+TILE_PIXEL_DIM};
        break;
    case 3:
        loc = {loc.getX()+TILE_PIXEL_DIM,loc.getY()};
        break;
    }
    im->setCenterLocation(loc);

}
