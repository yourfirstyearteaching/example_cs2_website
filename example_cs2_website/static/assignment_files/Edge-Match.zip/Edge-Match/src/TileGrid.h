#pragma once

/* DO NOT MODIFY THIS FILE UNLESS YOU
 * ARE WORKING ON AN EXTENSION
 */

#include "vector.h"
#include "grid.h"
#include "gobjects.h"
#include "map.h"
#include "Tile.h"

using namespace std;

const int TILE_PIXEL_DIM = 200; // 200px x 200px images

struct ImageAndRotation {
    GImage *im;
    int orientation;
    string sidesStr;
};

class TileGrid {
public:
    ~TileGrid();
    bool populate(string filename, string imageDir);
    void loadImages(string imageDir);
    void drawTiles();
    void placeTile(Tile &tile, int row, int col);
    Grid<Tile> &getGrid();
    bool saveGrid(string filename);
    GWindow &getWindow();
    Map<string,ImageAndRotation> &getImages();
    Vector<Tile> getTileVec();
    void swapImages(ImageAndRotation im1, ImageAndRotation im2);
    void updateTile(ImageAndRotation im);
    string toString();
    void replaceGrid(Grid<Tile> newTiles);
private:
    Grid<Tile> tiles;
    Map<string,ImageAndRotation> images;
    GWindow gw;
};
