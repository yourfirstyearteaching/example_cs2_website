#include <iostream>
#include "console.h"
#include "grid.h"
#include "filelib.h"
#include "strlib.h"
#include "simpio.h"
#include "timer.h"

#include "PlayGame.h"
#include "Tile.h"
#include "TileGrid.h"

using namespace std;

bool allMatch(Grid<Tile> &tiles);
void populateGrid(Grid<Tile> &tiles, Vector<Tile> &tileVec);
Vector<Grid<Tile>> solvePuzzle(TileGrid &tg, bool timeIt = false);
bool loadPuzzle(TileGrid &tg);
void manualPlay(TileGrid &tg);

// TODO: add parameters
void solvePuzzle_helper(/*parameters*/);

/* allMatch
 * The allMatch function returns true if the grid of tiles
 * is a solution to the tile-match puzzle.
 *
 * Parameter:
 *     Grid<Tile> &tiles
 *         This is a reference to a Grid of tiles, which you can
 *         obtain using the  Grid<Tile> &TileGrid::getGrid() function.
 */
bool allMatch(Grid<Tile> &tiles) {
    // TODO: Write this function
    return false;
}

/* solvePuzzle
 * The solvePuzzle function returns a Vector of Grid<Tile>
 * grids that are solutions to the tile-puzzle.
 *
 * Parameters:
 *     TileGrid &tg
 *         This is a reference to an instance of a TileGrid, which holds
 *         information about the Grid<Tile> grid, and also has information
 *         on the images used for the GUI.
 *
 *     bool timeIt
 *         A true value means that the solution solver is being timed,
 *         and therefore, there should be no user interaction. A false
 *         value means that you should visually display every solution
 *         (using the tg.drawTiles() function), and you should
 *         ask the user if they want to save each solution. Saving a
 *         solution is done with the tg.saveGrid(string filename) function.
 */
Vector<Grid<Tile>> solvePuzzle(TileGrid &tg, bool timeIt) {
    // recursively populate tiles and check solution
    Vector<Grid<Tile>> solutions;
    Vector<Tile> tileVec = tg.getTileVec();

    // TODO: call your recursive solvePuzzle_helper function

    return solutions;
}


void solvePuzzle_helper(/*parameters*/) {
    // TODO: add parameters and complete the recursive function
}

/* DO NOT MODIFY ANYTHING BELOW THIS LINE UNLESS YOU ARE WORKING
 * ON AN EXTENSION
 */

int main() {
    setConsoleWindowTitle("Tile Match");
    setConsoleSize(600, 600);
    cout << "Welcome to the tile match game!" << endl;

    while (true) {
        bool timeIt = false;
        TileGrid tg;
        Timer t;

        if (!loadPuzzle(tg)) {
            cout << "Could not load puzzle." << endl;
            return -1;
        }

        cout << "Beginning tiles: " << endl;
        cout << tg.toString() << endl;
        manualPlay(tg);

        string response = getLine("Would you like to time your solution (y/N)? ");
        if (response != "" && toupper(response[0]) == 'Y') {
            timeIt = true;
        }
        getLine("Press <enter> to start searching for solutions.");
        cout << endl;

        if (timeIt) {
            t.start();
        }

        Vector<Grid<Tile>> solutions = solvePuzzle(tg, timeIt);

        if (timeIt) {
            t.stop();
            cout << "Time: " << t.elapsed() << "ms" << endl;
        }

        cout << "Found " << solutions.size() << " solutions:" << endl;
        for (Grid<Tile> tiles : solutions) {
            tg.replaceGrid(tiles);
            cout << tg.toString() << endl;
        }
        string playAgain = getLine("Would you like to play again (Y/n)? ");
        if (playAgain != "" && tolower(playAgain[0]) == 'n') break;
        tg.getWindow().close();
    }
    cout << "Thank you for plaing the tile match game!" << endl;
    return 0;
}

bool loadPuzzle(TileGrid &tg) {
    // list puzzle directories
    int i = 0;

    Vector<string>files;
    Vector<string>allowableFiles;

    listDirectory("puzzles",files);

    for (string f : files) {
        if (isDirectory("puzzles/" + f)) {
            allowableFiles.add(f);
            i++;
            cout << i << ". " << f << endl;
        }
    }

    int response = -1;
    while (response < 1 || response > files.size()) {
        response = getInteger("Choose a number: ",
                              "Please enter a number.");
    }
    cout << endl;
    string puzzleDir = "puzzles/" + allowableFiles[response-1];

    listDirectory(puzzleDir,files);
    cout << "Please choose the number of the file you would like to load:" << endl << endl;

    i = 0;
    allowableFiles.clear();
    for (string f : files) {
        if (matchFilenamePattern(f,"*.txt")) {
            allowableFiles.add(f);
            i++;
            cout << i << ". " << f << endl;
        }
    }

    response = -1;
    while (response < 1 || response > allowableFiles.size()) {
        response = getInteger("Choose a number:",
                              "Please enter a number.");
    }

    string filename = allowableFiles[response-1];

    if (!tg.populate(filename, puzzleDir)) {
        return false;
    }

    setConsoleLocation(tg.getWindow().getX() + tg.getWindow().getWidth() + 120,0);
    cout << endl;
    return true;
}

void manualPlay(TileGrid &tg) {
    string response = getLine("Would you like to play the game manually (y/N)? ");
    if (response != "" && toupper(response[0]) == 'Y')  {
        cout << "Have fun! Use the mouse to move pieces, and click on a piece to" << endl;
        cout << "rotate the piece 90 degrees clockwise." << endl;
        cout << "Press any key on the keyboard to quit manual play mode." << endl;
        PlayGame(tg,allMatch);
    }

}


