#include "Tile.h"
#include <cctype>
#include "vector.h"
#include "strlib.h"

using namespace std;

/* Tile::Tile()
 * This constructor creates a default Tile with X as each edge,
 * and an orientation of 0 for the tile.
 */
// note: uppercase letters are heads, and
// lowercase letters are tails.
Tile::Tile() {
    sides.add("X");
    sides.add("X");
    sides.add("x");
    sides.add("x");
    orientation = 0; // top faces up
}

/* Tile::Tile(string s)
 * This constructor creates a tile by parsing the
 * string s in the form "A B a b 0"
 *  where the end digit is the orientation, and is optional
 */
Tile::Tile(string s) {
    // TODO: Write this constructor
}

/* Tile::getOrientation
 * This function returns the orientation of the tile.
 */
int Tile::getOrientation() {
    // TODO: write this function
    return 0; // remove as necessary
}

/* Tile::setOrientation
 * This function sets the orientation of the tile
 * based on the parameter.
 */
void Tile::setOrientation(int orientation) {
    // TODO: write this function
}

/* Tile::sidesStr()
 * This function returns a string in the form
 * "ABcd", which will be used to define a tile.
 * The string returned does not indicate the
 * orientation of the tile.
 */
string Tile::sidesStr() const {
    // TODO: write this function
    return ""; // remove as necessary
}

/* Tile::isMatched()
 * This function returns true if the other tile in the location
 * relative to this tile is a match.
 *
 * Parameters:
 *     Tile &other
 *         other is a reference to another Tile that will be compared for matching
 *     Connection otherLocation
 *         otherLocation is a Connection (ABOVE, RIGHT, BELOW, LEFT) for the
 *         location of the tile relative to this tile. For example, if
 *         otherLocation is ABOVE, then a match returns true if this tile
 *         in its current orientation matches the other tile in its orientation when
 *         the other tile is above this tile.
 */
bool Tile::isMatched(Tile &other, Connection otherLocation) {
    // TODO: write this function
    return false; // remove as necessary
}

/* operator<<()
 * This overloaded friend function to the Tile class
 * outputs a string in the following form:
 * A B C D 0
 * Which means that with an orientation of 0, the piece
 * would look like this:
 *  A
 * C B
 *  D
 *
 * If we had this:
 * A B C D 3
 * The piece would look like this, because it has been
 * rotated clockwise 3 times:
 *  B
 * A C
 *  D
 *
 * Parameters:
 *     ostream &out
 *         This is the output ostream which will be used by
 *         (for example) cout or for printing to a file.
 *     Tile const &tile
 *         This is the tile we will send to out.
 */
ostream &operator<<(ostream &out, Tile const &tile) {
    // TODO: write this function
    return out;
}
