The puzzles directory holds puzzles for the edge matching game.

Each puzzle folder has tile images (in .png form) and at least one .txt
file which describes the initial state of the tiles in a game.

There may or may not be other files, such as labeled images, etc. The tiles
in the form dbCA.png are the only images necessary for the game. 
